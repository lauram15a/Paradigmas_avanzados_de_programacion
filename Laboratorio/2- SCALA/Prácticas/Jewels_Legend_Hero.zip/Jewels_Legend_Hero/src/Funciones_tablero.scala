class Funciones_tablero {

}
